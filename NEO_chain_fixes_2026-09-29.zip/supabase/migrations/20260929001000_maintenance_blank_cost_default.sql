-- An omitted estimate is valid; never insert NULL into the non-null cost_estimate column.
CREATE OR REPLACE FUNCTION public.neo_maintenance_work_order_create(_payload jsonb, _idempotency_key text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  _org uuid := public.current_org_id();
  _branch uuid := NULLIF(_payload->>'branch_id','')::uuid;
  _room uuid := NULLIF(_payload->>'room_id','')::uuid;
  _asset uuid := NULLIF(_payload->>'asset_id','')::uuid;
  _category uuid := NULLIF(_payload->>'category_id','')::uuid;
  _department uuid := NULLIF(_payload->>'requesting_department_id','')::uuid;
  _assignee uuid := NULLIF(_payload->>'assigned_to','')::uuid;
  _description text := btrim(COALESCE(_payload->>'description',''));
  _priority text := COALESCE(NULLIF(_payload->>'priority',''),'normal');
  _blocks boolean := COALESCE((_payload->>'blocks_room')::boolean, false);
  _severity text := COALESCE(NULLIF(_payload->>'block_status',''),'out-of-order');
  _existing public.maintenance_work_orders;
  _wo public.maintenance_work_orders;
  _number text;
  _room_state jsonb;
BEGIN
  IF _org IS NULL THEN RAISE EXCEPTION 'No active organisation'; END IF;
  IF NOT (public.has_permission('maintenance','edit') OR public.has_permission('housekeeping','edit')
          OR public.has_permission('laundry','edit') OR public.is_org_admin()) THEN
    RAISE EXCEPTION 'Not permitted to report maintenance faults';
  END IF;
  IF _description = '' THEN RAISE EXCEPTION 'Describe the fault before reporting it'; END IF;
  IF NULLIF(btrim(COALESCE(_idempotency_key,'')), '') IS NULL THEN RAISE EXCEPTION 'A work-order idempotency key is required'; END IF;
  IF _branch IS NULL OR NOT EXISTS (SELECT 1 FROM public.branches WHERE id = _branch AND organization_id = _org) THEN
    RAISE EXCEPTION 'Select a valid property';
  END IF;
  IF _room IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.rooms WHERE id = _room AND organization_id = _org AND branch_id = _branch
  ) THEN RAISE EXCEPTION 'The selected room does not belong to this property'; END IF;
  IF _asset IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.assets WHERE id = _asset AND organization_id = _org AND (branch_id IS NULL OR branch_id = _branch)
  ) THEN RAISE EXCEPTION 'The selected asset does not belong to this property'; END IF;
  IF _category IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.maintenance_categories WHERE id = _category AND organization_id = _org
  ) THEN RAISE EXCEPTION 'That maintenance category does not belong to this workspace'; END IF;

  SELECT * INTO _existing FROM public.maintenance_work_orders
   WHERE organization_id = _org AND idempotency_key = _idempotency_key;
  IF _existing.id IS NOT NULL THEN
    RETURN jsonb_build_object('ok', true, 'idempotent', true, 'work_order_id', _existing.id,
      'work_order_number', _existing.work_order_number, 'blocks_room', _existing.blocks_room);
  END IF;

  _number := public.next_document_number('work-order');
  INSERT INTO public.maintenance_work_orders
    (organization_id, branch_id, work_order_number, requesting_department_id, requested_by,
     room_id, location_label, asset_id, category_id, fault_category, description, priority, operational_impact,
     guest_impact, attachments, status, assigned_to, estimated_completion, cost_estimate,
     blocks_room, block_status, source_module, source_record_id, idempotency_key, created_by)
  VALUES
    (_org, _branch, _number, _department, auth.uid(), _room, NULLIF(_payload->>'location_label',''),
     _asset, _category,
     COALESCE(NULLIF(_payload->>'fault_category',''),
              (SELECT lower(coalesce(c.code, c.name)) FROM public.maintenance_categories c WHERE c.id = _category),
              'other'),
     _description, _priority,
     NULLIF(_payload->>'operational_impact',''), COALESCE((_payload->>'guest_impact')::boolean,false),
     COALESCE(_payload->'attachments','[]'::jsonb),
     CASE WHEN _assignee IS NOT NULL THEN 'assigned' ELSE 'new' END,
     _assignee,
     NULLIF(_payload->>'estimated_completion','')::timestamptz,
     COALESCE(NULLIF(_payload->>'cost_estimate','')::numeric, 0),
     _blocks AND _room IS NOT NULL,
     CASE WHEN _blocks AND _room IS NOT NULL THEN _severity ELSE NULL END,
     COALESCE(NULLIF(_payload->>'source_module',''),'maintenance'),
     NULLIF(_payload->>'source_record_id','')::uuid, _idempotency_key, auth.uid())
  RETURNING * INTO _wo;

  INSERT INTO public.work_order_status_history
    (organization_id, work_order_id, previous_status, new_status, reason, changed_by)
  VALUES (_org, _wo.id, NULL, _wo.status, 'Work order created', auth.uid());

  IF _blocks AND _room IS NOT NULL THEN
    PERFORM set_config('neo.system_posting', 'on', true);
    _room_state := public.ops_set_room_status(_room, NULL, _severity, _description, 'maintenance', _wo.id, NULL);
  END IF;

  INSERT INTO public.audit_logs
    (organization_id, branch_id, user_id, user_name, action, module, record_id, new_value)
  VALUES (_org, _branch, auth.uid(), '', 'maintenance.work_order.created', 'maintenance', _wo.id::text,
    jsonb_build_object('work_order_number',_number,'room_id',_room,'asset_id',_asset,'category_id',_category,
                       'blocks_room',_wo.blocks_room,'room_state',_room_state));

  RETURN jsonb_build_object('ok', true, 'idempotent', false, 'work_order_id', _wo.id,
    'work_order_number', _number, 'blocks_room', _wo.blocks_room, 'room_state', _room_state);
END; $$;
